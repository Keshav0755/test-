// DATATYPES
#include <iostream>
using namespace std; 
//code for sum of two numbers
//types of data types 
//char = characters , example - char a = 'x'; 
//for string we use double quotes 
// 
//
int main() {

//assignment 
  
// 1. Write a program in C++ to add two numbers accept through keyboard.

/*
int a  ; 
int b ; 
int c ;
cout << "Enter two values that you want to add :- " <<endl ; 
cin >> a ; 
cin >> b ; 
c = a+b ; 
cout  << "sum of two numbers  are  "<< c  <<endl ; 
*/

// 2. Write a program in C++ to find Size of fundamental data types.
/*
int a ; 
float b ; 
bool c  ; 
cout << "get the size of  integer data types" <<endl ;  
cin >> a ; 
int size1  = sizeof(a); 
  cout <<  "size of integer is " << size1 << endl ;
  
cout << "get the size of float data type" <<endl ; 
cin >> b ; 
float size2  = sizeof(b) ; 
cout <<  "size of float is " << size2 << endl ; 
  
cout << "get the size of boolean data type " <<endl ; 
cin >> c  ; 
bool size3 = sizeof(c) ; 
cout << "size of boolean data type is "<< size3 << endl ; */

// 3. Write a program in C++ to display the operation of pre and post increment and decrement.

/* int x = 10, a;
a = x++;
cout << "Post Increment Operation";
// Value of a will not change
cout << "\na = " << a;
// Value of x change after execution of a=x++;
cout << "\nx = " << x;
return 0;*/


//4. Write a C++ program to check if a given positive number is a multiple of 3 or a multiple of 7.
/*int a ; 
cin >> a ;
if (a%3==0){
  cout << "the number is divisible by 3" << endl ; }
else if (a%7==0)
  {cout << "the number is divisibe by 7 " <<endl ; }
  else {
   cout<< "number is not divisible by 3 or 7 " <<endl ; 
  } */

//5. Write a C++ program to check the largest number among three given integers.
/*
int a  ; 
int b ; 
int c ; 
cin >> a ; 
cin >> b ; 
cin >> c ; 
if (a>b && a>c) { 
  cout << "a is largest digit"<< endl ;}
  
   if (b>a && b>c) {
     cout << " b is largest digit"<< endl ; 
  }
if (c>a && c>b){  cout << " c is largest digit"<< endl ; } */
 
//6.Write a program in C++ to find the sum of digits of a given number.
   /*int x, s = 0;
   cout << "Enter the number : ";
   cin >> x;
   while (x != 0) {
      s = s + x % 10;
      x = x / 10;
   }
   cout << "\nThe sum of the digits : "<< s;*/
  
//7 Write a program in C++ to find the factorial of a number.
/*
  int num,factorial=1;
	cout<<" Enter Number To Find Its Factorial:  ";
	cin>>num;
	for (int a=1;a<=num;a++) {
		factorial=factorial*a;
	}
	cout<<"Factorial of Given Number is ="<<factorial<<endl;
	return 0;*/
  
//8. Write a program in C++ to calculate the sum of the series (1*1) + (2*2) + (3*3) + (4*4) + (5*5) + ... + (n*n).
/*int  i , n , sum=0 ; 
  cin >> n ; 


    for (i = 1; i <= n; i++) 
	{
        sum += i * i;
        cout << i << "*" << i << " = " << i * i << endl;
    }
    cout << " The sum of the above series is: " << sum << endl; */
 
//9. Write a program in C++ to swap two numbers using third variable.
  //explained in clss
 /* int a ; 
  int  b ; 
  int thirdnum ; 
  cin >> a ; 
  cin >> b ; 
  cout << "*before swapping first number = " << a  <<endl << " *before swapping second number = " << b <<endl ; 
  //after swapping two digits 
 thirdnum = a ; 
a = b ; 
b = thirdnum ;
cout << "#after swapping  first number = " <<a  << endl << " #after swapping second number  = " << b << endl ; */
    
//10. Write a program in C++ which swap the values of two variables not using third variable.
/* int a  ; 
int b ; 
 cin >> a ;
cin >> b ; 
   cout << "*before swapping first number = " << a  <<endl << " *before swapping second number = " << b <<endl ; 
//after swapping 
  b = b+a; 
  b = b-a; 
  a = b-a ;

  cout << "#after swapping  first number = " <<a << endl << " #after swapping second number  = " << b << endl ;*/
  // while loops 
/*int n ; 
cin >> n ; 
int  i = 1; 
  while (i<=n){
    cout << i << endl ; 
    i = i+1 ; 
  }*/
     
 // check that given no. i prime or not 
 /* int n ; 
  cin >> n ; 
  int d = 2  ; 
  while(d<n){
    if (d%2==0){
      cout << "not prime"<< endl ; }
    else {
        cout << "prime" <<endl ; 
      }
    d = d + 1 ; 
  }*/
//for loop - for (initialisation , condition , updation)
  //sum of n numbers 
 /* int n ; 
  cout << "enter the value of n " << endl ; 
  cin >>  n ; 

int   sum = 0 ; 
  for (int counter = 1 ; counter <= n ; counter ++ ){
    sum = sum + counter ;
  }
  cout << "sum of n numbers is " << sum << endl ; */

//while loops - while (condtionis true){body}
 /* int n ; 
  cin >> n ; 
  while (n>0){
    cout << n << endl ; 
    cin >> n ;  
    }*/

//do while loops - 
/*  do {body }
  while (condtion); */

// practise programs 
/*int n;

cout << "Enter a positive integer: ";
cin >> n;

for (int i = 1; i <= 10; ++i) {
cout << n << " * " << i << " = " << n * i << endl;
}

return 0; */

  
  
  
  
  

}